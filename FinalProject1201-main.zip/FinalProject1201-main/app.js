const express = require("express");
const app = express();
const path = require("path");
const fs = require("fs");

app.use(express.static("public"));

// Endpoint to get all courses
app.get("/courses", (req, res) => {
  const courses = JSON.parse(fs.readFileSync("./database/courses.json"));
  let filteredCourses = courses;

  if (req.query.code) {
    filteredCourses = filteredCourses.filter(
      (course) => course.code === req.query.code.toUpperCase()
    );
  }

  if (req.query.num) {
    const numString = req.query.num.toString();
    const numLength = numString.length;
    filteredCourses = filteredCourses.filter((course) => {
      const courseNumString = course.num.toString();
      const courseNumLength = courseNumString.length;
      if (numLength <= courseNumLength) {
        return courseNumString.startsWith(numString);
      }
      return numString.startsWith(courseNumString);
    });
  }

  res.send(filteredCourses);
});

// Endpoint to get user account by id
app.get("/account/:id", (req, res) => {
  const userId = parseInt(req.params.id);
  let users = JSON.parse(fs.readFileSync("./database/users.json"));
  const user = users.find((user) => user.id === userId);
  if (user) {
    res.send({ user });
  } else {
    res.status(404).send({ error: "User not found" });
  }
});

app.get("/login", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "login.html"));
});

app.get("/signup", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "signup.html"));
});

app.post("/login", (req, res) => {
  let users = loadUsers();

  for (let i = 0; i < users.length; i++) {
    if (users[i].username == req.body.username) {
      if (users[i].password == req.body.password) {
        res.json({ userId: users[i].id });
        return;
      } else {
        res.json({ userId: null, error: "wrong password" });
        return;
      }
    }
  }
  res.json({ userId: null, error: "account doesn't exist" });
});

app.post("/signup", (req, res) => {
  let users = loadUsers();

  for (let i = 0; i < users.length; i++) {
    if (users[i].username == req.body.username) {
      res.json({ userId: null, error: "username unavailable" });
      return;
    }
  }

  let newUser = {
    username: req.body.username,
    password: req.body.password,
    id: users.length + 1,
    courses: [
      {
        code: null,
        num: null,
        name: null,
        credits: null,
        description: null,
      },
    ],
  };
  users.push(newUser);

  writeUsers(users);

  res.json({ userId: newUser.id });

  res.redirect("/login");
});

function loadUsers() {
  return JSON.parse(fs.readFileSync("./database/users.json").toString());
}

function writeUsers(newData) {
  fs.writeFileSync("./database/users.json", JSON.stringify(newData));
}

module.exports = app;
